# INHERITANCE
#
# Define two classes in this file.
#
# The "Light" class must have no constructor. It can be an empty class.
#
# The "LED" class should inherit from the "Light" class. It should have
# an empty constructor. It can be an empty class.

# WRITE YOUR CODE HERE

class Light:
    pass


class LED(Light):
    def __init__(self):
        pass
